package com.example.productordermanagement.controller;

import com.example.productordermanagement.dto.OrderRequest;
import com.example.productordermanagement.model.Order;
import com.example.productordermanagement.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public Order create(@Valid @RequestBody OrderRequest req, Authentication auth) {
        if (auth == null || auth.getName() == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        return orderService.createOrder(auth.getName(), req);
    }

    @GetMapping
    public List<Order> myOrders(Authentication auth) {
        if (auth == null || auth.getName() == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        // if admin, return all orders
        boolean isAdmin = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        if (isAdmin) {
            return orderService.getAllOrders();
        }
        return orderService.getOrdersForUser(auth.getName());
    }

    @GetMapping("/{id}")
    public Order get(@PathVariable Long id, Authentication auth) {
        Order o = orderService.getById(id);
        if (!auth.getName().equals(o.getUsername()) && auth.getAuthorities().stream().noneMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        return o;
    }
}
