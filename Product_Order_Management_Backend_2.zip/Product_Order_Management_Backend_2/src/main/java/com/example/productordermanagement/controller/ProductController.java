package com.example.productordermanagement.controller;

import com.example.productordermanagement.dto.CreateProductRequest;
import com.example.productordermanagement.dto.ProductDTO;
import com.example.productordermanagement.model.Product;
import com.example.productordermanagement.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
@Validated
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public Page<ProductDTO> list(@RequestParam(required = false) String q,
                                 @RequestParam(required = false) String category,
                                 @RequestParam(defaultValue = "0") @Min(0) int page,
                                 @RequestParam(defaultValue = "10") @Min(1) @Max(100) int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Product> p = productService.search(q, category, pageable);
        List<ProductDTO> dtos = p.getContent().stream().map(this::toDto).collect(Collectors.toList());
        return new PageImpl<>(dtos, pageable, p.getTotalElements());
    }

    @GetMapping("/{id}")
    public ProductDTO get(@PathVariable Long id) {
        return productService.get(id).map(this::toDto).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProductDTO create(@Valid @RequestBody CreateProductRequest req) {
        Product p = productService.create(req);
        return toDto(p);
    }

    @PutMapping("/{id}")
    public ProductDTO update(@PathVariable Long id, @Valid @RequestBody CreateProductRequest req) {
        Product p = productService.update(id, req);
        return toDto(p);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        productService.delete(id);
    }

    private ProductDTO toDto(Product p) {
        ProductDTO d = new ProductDTO();
        d.id = p.getId();
        d.name = p.getName();
        d.description = p.getDescription();
        d.price = p.getPrice();
        d.category = p.getCategory();
        d.stock = p.getStock();
        return d;
    }
}
