package com.example.productordermanagement.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class CreateProductRequest {
    @NotBlank
    public String name;
    public String description;
    @NotNull
    public BigDecimal price;
    public String category;
    public Integer stock = 0;
}
