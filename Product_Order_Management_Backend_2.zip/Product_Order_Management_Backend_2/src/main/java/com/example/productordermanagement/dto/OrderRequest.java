package com.example.productordermanagement.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class OrderRequest {
    @NotEmpty
    public List<OrderLine> items;

    public static class OrderLine {
        @NotNull
        public Long productId;
        @NotNull
        public Integer quantity;
    }
}
