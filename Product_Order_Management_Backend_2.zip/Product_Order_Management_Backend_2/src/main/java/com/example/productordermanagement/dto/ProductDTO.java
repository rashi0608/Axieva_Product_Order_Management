package com.example.productordermanagement.dto;

import java.math.BigDecimal;

public class ProductDTO {
    public Long id;
    public String name;
    public String description;
    public BigDecimal price;
    public String category;
    public Integer stock;
}
