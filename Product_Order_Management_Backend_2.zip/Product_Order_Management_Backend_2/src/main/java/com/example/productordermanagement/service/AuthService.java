package com.example.productordermanagement.service;

import com.example.productordermanagement.dto.AuthRequest;
import com.example.productordermanagement.dto.AuthResponse;
import com.example.productordermanagement.model.User;
import com.example.productordermanagement.repository.UserRepository;
import com.example.productordermanagement.security.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.NoSuchElementException;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    public AuthResponse register(AuthRequest req) {
        if (userRepository.findByUsername(req.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }
        User u = new User();
        u.setUsername(req.getUsername());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setRoles(Collections.singleton("ROLE_USER"));
        userRepository.save(u);
        String token = jwtUtil.generateToken(u.getUsername(), Collections.singletonList("ROLE_USER"));
        return new AuthResponse(token);
    }

    public AuthResponse login(AuthRequest req) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
        } catch (Exception ex) {
            throw new BadCredentialsException("Invalid username/password");
        }
        User u = userRepository.findByUsername(req.getUsername()).orElseThrow(() -> new NoSuchElementException("User not found: " + req.getUsername()));
        String token = jwtUtil.generateToken(u.getUsername(), u.getRoles().stream().toList());
        return new AuthResponse(token);
    }
}
