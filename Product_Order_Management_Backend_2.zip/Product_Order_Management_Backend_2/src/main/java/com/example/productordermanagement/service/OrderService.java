package com.example.productordermanagement.service;

import com.example.productordermanagement.dto.OrderRequest;
import com.example.productordermanagement.model.Order;
import com.example.productordermanagement.model.OrderItem;
import com.example.productordermanagement.model.Product;
import com.example.productordermanagement.repository.OrderRepository;
import com.example.productordermanagement.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository, ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    public Order createOrder(String username, OrderRequest req) {
        Order order = new Order();
        order.setUsername(username);

        List<OrderItem> items = req.items.stream().map(line -> {
            Product p = productRepository.findById(line.productId).orElseThrow(() -> new NoSuchElementException("Product not found with id: " + line.productId));
            if (p.getStock() < line.quantity) {
                throw new IllegalArgumentException("Insufficient stock for product " + p.getName());
            }
            OrderItem it = new OrderItem();
            it.setProductId(p.getId());
            it.setProductName(p.getName());
            it.setQuantity(line.quantity);
            it.setPrice(p.getPrice());
            it.setOrder(order);
            // reduce stock
            p.setStock(p.getStock() - line.quantity);
            productRepository.save(p);
            return it;
        }).collect(Collectors.toList());

        BigDecimal total = items.stream().map(i -> i.getPrice().multiply(BigDecimal.valueOf(i.getQuantity()))).reduce(BigDecimal.ZERO, BigDecimal::add);
        order.setItems(items);
        order.setTotal(total);
        order.setStatus("CREATED");
        return orderRepository.save(order);
    }

    public List<Order> getOrdersForUser(String username) { return orderRepository.findByUsername(username); }

    public Order getById(Long id) { return orderRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Order not found with id: " + id)); }

    public List<Order> getAllOrders() { return orderRepository.findAll(); }
}
