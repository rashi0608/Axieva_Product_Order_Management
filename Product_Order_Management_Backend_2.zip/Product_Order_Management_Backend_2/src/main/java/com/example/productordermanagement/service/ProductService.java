package com.example.productordermanagement.service;

import com.example.productordermanagement.dto.CreateProductRequest;
import com.example.productordermanagement.model.Product;
import com.example.productordermanagement.repository.ProductRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.NoSuchElementException;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product create(CreateProductRequest req) {
        Product p = new Product();
        p.setName(req.name);
        p.setDescription(req.description);
        p.setPrice(req.price);
        p.setCategory(req.category);
        p.setStock(req.stock);
        return productRepository.save(p);
    }

    public Optional<Product> get(Long id) { return productRepository.findById(id); }

    public Page<Product> search(String q, String category, Pageable pageable) {
        return productRepository.search(q, category, pageable);
    }

    public Product update(Long id, CreateProductRequest req) {
        Product p = productRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Product not found with id: " + id));
        p.setName(req.name);
        p.setDescription(req.description);
        p.setPrice(req.price);
        p.setCategory(req.category);
        p.setStock(req.stock);
        return productRepository.save(p);
    }

    public void delete(Long id) {
        if (!productRepository.existsById(id)) {
            throw new NoSuchElementException("Product not found with id: " + id);
        }
        productRepository.deleteById(id);
    }
}
