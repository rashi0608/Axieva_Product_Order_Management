INSERT INTO products (name, description, price, category, stock) VALUES ('Electronic A', 'Washing Machine, Television', 19.99, 'General', 10);
INSERT INTO products (name, description, price, category, stock) VALUES ('Furniture B', 'Sofa, Almirah', 29.99, 'General', 5);
INSERT INTO products (name, description, price, category, stock) VALUES ('Cosmetics C', 'All Products', 9.50, 'Accessories', 20);
