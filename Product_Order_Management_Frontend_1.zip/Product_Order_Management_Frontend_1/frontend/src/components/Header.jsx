'use client'

import { Link, useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { logout } from '@/store/slices/authSlice'

export default function Header() {
  const cartItems = useSelector((state) => state.cart.items)
  const user = useSelector((state) => state.auth.user)
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const handleLogout = () => {
    dispatch(logout())
    navigate('/')
  }

  return (
    <header className="bg-blue-600 text-white">
      <div className="container mx-auto flex flex-wrap items-center justify-between gap-3 px-4 py-4">
        <Link to="/" className="text-xl font-bold">Product Store</Link>
        <div className="flex flex-wrap items-center gap-3">
          <Link to="/products" className="hover:underline">Products</Link>
          <Link to="/cart" className="hover:underline">Cart ({cartItems.length})</Link>
          {user ? (
            <>
              <Link to="/orders" className="hover:underline">Orders</Link>
              <button onClick={handleLogout} className="rounded-lg border border-white px-3 py-2 hover:bg-white hover:text-blue-600">
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="hover:underline">Login</Link>
          )}
        </div>
      </div>
    </header>
  )
}
