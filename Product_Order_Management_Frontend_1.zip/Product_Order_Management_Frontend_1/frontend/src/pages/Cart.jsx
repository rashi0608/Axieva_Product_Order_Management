'use client'

import { useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { removeFromCart, updateQuantity, clearCart } from '@/store/slices/cartSlice'
import api from '@/lib/api'

export default function Cart() {
  const cartItems = useSelector((state) => state.cart.items)
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false)

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const handleCheckout = async () => {
    setLoading(true)
    try {
      await api.post('/orders', { items: cartItems.map((item) => ({ productId: item.productId, quantity: item.quantity })) })
      alert('Order placed successfully')
      dispatch(clearCart())
    } catch (error) {
      alert('Unable to place order')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="rounded-xl bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold mb-6">Cart</h1>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <div className="space-y-4">
            {cartItems.map((item) => (
              <div key={item.productId} className="flex flex-col gap-3 rounded-xl border p-4 md:flex-row md:justify-between md:items-center">
                <div>
                  <h2 className="text-xl font-semibold">{item.name}</h2>
                  <p>${item.price.toFixed(2)} each</p>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <input
                    type="number"
                    min="1"
                    value={item.quantity}
                    onChange={(e) => dispatch(updateQuantity({ productId: item.productId, quantity: Number(e.target.value) }))}
                    className="w-20 rounded-lg border p-2"
                  />
                  <button onClick={() => dispatch(removeFromCart(item.productId))} className="rounded-lg bg-red-600 px-4 py-2 text-white hover:bg-red-700">
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xl font-semibold">Total: ${total.toFixed(2)}</p>
            </div>
            <button
              onClick={handleCheckout}
              disabled={loading}
              className="rounded-lg bg-blue-600 px-6 py-3 text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Placing order...' : 'Checkout'}
            </button>
          </div>
        </>
      )}
    </div>
  )
}
