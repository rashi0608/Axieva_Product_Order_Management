'use client'

import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="space-y-10 py-10">
      <div className="rounded-2xl bg-white px-8 py-10 shadow-sm">
        <h1 className="text-4xl font-bold mb-3">Product Order Management</h1>
        <p className="text-gray-600 max-w-2xl">
          This simple product and order management app connects a React frontend with your Spring Boot backend.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <Link to="/products" className="rounded-xl bg-white p-6 shadow-sm hover:shadow-lg transition">
          <h2 className="text-xl font-semibold mb-2">Products</h2>
          <p className="text-gray-600">Browse products with search, filters, and pagination.</p>
        </Link>
        <Link to="/cart" className="rounded-xl bg-white p-6 shadow-sm hover:shadow-lg transition">
          <h2 className="text-xl font-semibold mb-2">Cart</h2>
          <p className="text-gray-600">Review cart items and place an order.</p>
        </Link>
        <Link to="/orders" className="rounded-xl bg-white p-6 shadow-sm hover:shadow-lg transition">
          <h2 className="text-xl font-semibold mb-2">Orders</h2>
          <p className="text-gray-600">See your order history once you login.</p>
        </Link>
      </div>
    </div>
  )
}
