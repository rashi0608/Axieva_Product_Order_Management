'use client'

import { useEffect, useState } from 'react'
import api from '@/lib/api'

export default function Orders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await api.get('/orders')
        setOrders(response.data)
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchOrders()
  }, [])

  if (loading) {
    return <div className="rounded-xl bg-white p-8 shadow-sm">Loading orders...</div>
  }

  return (
    <div className="rounded-xl bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold mb-6">Orders</h1>
      {orders.length === 0 ? (
        <p>No orders found. Please login and place an order.</p>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <div key={order.id} className="rounded-xl border p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Order #{order.id}</h2>
                <span className="rounded-full bg-gray-100 px-3 py-1 text-sm">{order.status}</span>
              </div>
              <p className="text-gray-600">Placed on {new Date(order.createdAt).toLocaleDateString()}</p>
              <p className="mt-2 font-semibold">Total: ${order.total}</p>
              <div className="mt-3 space-y-2">
                {order.items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm text-gray-700">
                    <span>{item.productName} x {item.quantity}</span>
                    <span>${item.price}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
