'use client'

import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import api from '@/lib/api'
import { addToCart } from '@/store/slices/cartSlice'

export default function ProductDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadProduct = async () => {
      if (!id) return
      try {
        const response = await api.get(`/products/${id}`)
        setProduct(response.data)
      } catch {
        navigate('/products')
      } finally {
        setLoading(false)
      }
    }
    loadProduct()
  }, [id, navigate])

  if (loading) {
    return <div className="rounded-xl bg-white p-8 shadow-sm">Loading product...</div>
  }

  if (!product) {
    return null
  }

  const handleAddToCart = () => {
    dispatch(addToCart({ productId: product.id, name: product.name, price: product.price, quantity: 1 }))
  }

  return (
    <div className="rounded-xl bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
      <p className="text-gray-600 mb-4">{product.description}</p>
      <p className="text-2xl font-semibold mb-2">${product.price}</p>
      <p className="mb-2">Category: {product.category}</p>
      <p className="mb-4">Stock: {product.stock}</p>
      <button onClick={handleAddToCart} className="rounded-lg bg-green-600 px-6 py-2 text-white hover:bg-green-700">
        Add to Cart
      </button>
    </div>
  )
}
