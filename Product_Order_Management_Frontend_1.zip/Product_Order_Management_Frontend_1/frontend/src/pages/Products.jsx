'use client'

import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import api from '@/lib/api'
import { addToCart } from '@/store/slices/cartSlice'

export default function Products() {
  const [products, setProducts] = useState([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const dispatch = useDispatch()

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true)
      try {
        const params = new URLSearchParams({ page: page.toString(), size: '10' })
        if (search) params.append('q', search)
        if (category) params.append('category', category)
        const response = await api.get(`/products?${params.toString()}`)
        setProducts(response.data.content || [])
        setTotalPages(response.data.totalPages || 1)
      } catch (error) {
        console.error(error)
      } finally {
        setLoading(false)
      }
    }
    fetchProducts()
  }, [search, category, page])

  const handleAddToCart = (product) => {
    dispatch(addToCart({ productId: product.id, name: product.name, price: product.price, quantity: 1 }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Products</h1>
          <p className="text-gray-600">Search and browse available items.</p>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <input
          type="text"
          placeholder="Search products"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="rounded-lg border p-3"
        />
        <input
          type="text"
          placeholder="Category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-lg border p-3"
        />
        <div className="rounded-lg border p-3 bg-white">
          <p className="text-sm text-gray-600">Page {page + 1} of {totalPages}</p>
        </div>
      </div>

      {loading ? (
        <div className="rounded-xl bg-white p-8 text-center shadow-sm">Loading products...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          {products.map((product) => (
            <div key={product.id} className="rounded-xl bg-white p-5 shadow-sm">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="text-gray-600 mb-3">{product.description}</p>
              <p className="font-semibold mb-2">${product.price}</p>
              <p className="text-sm text-gray-500 mb-3">Stock: {product.stock}</p>
              <div className="flex flex-wrap gap-2">
                <Link to={`/products/${product.id}`} className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
                  View
                </Link>
                <button
                  onClick={() => handleAddToCart(product)}
                  className="rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700"
                >
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-between gap-4">
        <button
          onClick={() => setPage((prev) => Math.max(prev - 1, 0))}
          disabled={page === 0}
          className="rounded-lg bg-gray-800 px-4 py-2 text-white disabled:opacity-50"
        >
          Previous
        </button>
        <button
          onClick={() => setPage((prev) => Math.min(prev + 1, totalPages - 1))}
          disabled={page >= totalPages - 1}
          className="rounded-lg bg-gray-800 px-4 py-2 text-white disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </div>
  )
}
